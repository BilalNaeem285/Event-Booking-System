export enum EventStatus {
  UPCOMING = 'UPCOMING',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED',
}
