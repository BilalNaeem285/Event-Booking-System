import { IsString, IsNumber, IsDateString } from 'class-validator';

export class CreateEventDto {
  @IsString()
  name: string;

  @IsString()
  description: string;

  @IsString()
  category: string;

  @IsString()
  location: string;

  @IsDateString()
  date: string;

  @IsString()
  time: string;

  @IsNumber()
  totalTickets: number;

  @IsNumber()
  ticketPrice: number;
}
