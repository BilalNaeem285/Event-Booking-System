import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Event } from '../database/entities/event.entity';
import { Booking } from '../database/entities/booking.entity';
import { User } from '../database/entities/user.entity';
import { CreateEventDto } from './dto/create-event.dto';
import { EventStatus } from '../common/enums/event-status.enum';
import { PaymentsService } from '../payments/payments.service';

@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event)
    private readonly eventRepo: Repository<Event>,

    @InjectRepository(Booking)
    private readonly bookingRepo: Repository<Booking>,

    @InjectRepository(User)
    private readonly userRepo: Repository<User>,

    private readonly paymentsService: PaymentsService,
  ) {}

  // CREATE EVENT (CREATOR)
  async createEvent(dto: CreateEventDto, creatorId: string) {
    const creator = await this.userRepo.findOneBy({ id: creatorId });
    if (!creator) throw new NotFoundException('Creator not found');

    const event = this.eventRepo.create({
      ...dto,
      availableTickets: dto.totalTickets,
      creator,
    });

    return this.eventRepo.save(event);
  }

  // LIST EVENTS
  async listEvents() {
    return this.eventRepo.find({
      where: { status: EventStatus.UPCOMING },
    });
  }

  // BOOK TICKET (USER)
  async bookTicket(
    eventId: number,
    userId: string,
    cardNumber: string,
  ) {
    const event = await this.eventRepo.findOne({
      where: { id: eventId },
      relations: ['creator'], // creator needed for payment
    });

    if (!event) throw new NotFoundException('Event not found');
    if (event.availableTickets < 1)
      throw new BadRequestException('No tickets available');

    const user = await this.userRepo.findOneBy({ id: userId });
    if (!user) throw new NotFoundException('User not found');

    const booking = this.bookingRepo.create({ event, user });
    await this.bookingRepo.save(booking);

    event.availableTickets -= 1;
    await this.eventRepo.save(event);

    // 💳 Payment (Option 1: cardNumber comes from controller)
    await this.paymentsService.payForBooking(
      booking,
      user,
      event.creator,
      event.ticketPrice,
    );

    return booking;
  }

  // CANCEL A SINGLE BOOKING (USER)
  async cancelBooking(bookingId: number, userId: string) {
    const booking = await this.bookingRepo.findOne({
      where: { id: bookingId },
      relations: ['user', 'event', 'event.creator'], // ✅ load everything needed
    });

    if (!booking) throw new NotFoundException('Booking not found');
    if (booking.user.id !== userId)
      throw new ForbiddenException('Not your booking');

    booking.cancelled = true;
    await this.bookingRepo.save(booking);

    booking.event.availableTickets += 1;
    await this.eventRepo.save(booking.event);

    // 💰 Refund
    await this.paymentsService.refundBooking(
      booking,
      booking.user,
      booking.event.creator,
      booking.event.ticketPrice,
    );

    return booking;
  }

  // CANCEL ENTIRE EVENT (CREATOR)
  async cancelEvent(eventId: number, creatorId: string) {
    const event = await this.eventRepo.findOne({
      where: { id: eventId },
      relations: [
        'creator',
        'bookings',
        'bookings.user',
        'bookings.event', // 🔥 CRITICAL (Option 1 fix)
      ],
    });

    if (!event) throw new NotFoundException('Event not found');
    if (event.creator.id !== creatorId)
      throw new ForbiddenException('Not your event');

    event.status = EventStatus.CANCELLED;
    await this.eventRepo.save(event);

    for (const booking of event.bookings) {
      booking.cancelled = true;
      await this.bookingRepo.save(booking);

      await this.paymentsService.refundBooking(
        booking,
        booking.user,
        event.creator,
        event.ticketPrice,
      );
    }

    return event;
  }
}
