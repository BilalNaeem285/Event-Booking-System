import {
  Controller,
  Post,
  Body,
  UseGuards,
  Request,
  Get,
  Param,
  ParseIntPipe,
} from '@nestjs/common';
import { EventsService } from './events.service';
import { CreateEventDto } from './dto/create-event.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { UserRole } from '../common/enums/user-role.enum';

@Controller('events')
export class EventsController {
  constructor(private readonly eventsService: EventsService) {}

  // Create a new event (CREATOR only)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.CREATOR)
  @Post('create')
  createEvent(@Body() dto: CreateEventDto, @Request() req) {
    return this.eventsService.createEvent(dto, req.user.id);
  }

  // List all upcoming events
  @Get()
  listEvents() {
    return this.eventsService.listEvents();
  }

  // Book a ticket (USER only)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.USER)
  @Post('book/:eventId')
  bookTicket(
    @Param('eventId', ParseIntPipe) eventId: number,
    @Body('cardNumber') cardNumber: string,
    @Request() req,
  ) {
    return this.eventsService.bookTicket(eventId, req.user.id, cardNumber);
  }

  // Cancel an event (CREATOR only)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.CREATOR)
  @Post('cancel/:eventId')
  cancelEvent(
    @Param('eventId', ParseIntPipe) eventId: number,
    @Request() req,
  ) {
    return this.eventsService.cancelEvent(eventId, req.user.id);
  }

  // Cancel a booking (USER only)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.USER)
  @Post('cancel-booking/:bookingId')
  cancelBooking(
    @Param('bookingId', ParseIntPipe) bookingId: number,
    @Request() req,
  ) {
    return this.eventsService.cancelBooking(bookingId, req.user.id);
  }
}
