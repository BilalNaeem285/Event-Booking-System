import React, { useState } from 'react';
import API from '../api/axios';
import { useNavigate } from 'react-router-dom';

const Register: React.FC = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    role: 'USER',
  });
  const [error, setError] = useState('');

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // FRONTEND VALIDATION
    if (form.phone.length !== 11) {
      setError('Phone number must be exactly 11 digits');
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      await API.post('/auth/register', form);
      alert('Registration successful!');
      navigate('/login');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register</h2>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <input
        name="name"
        placeholder="Name"
        required
        onChange={handleChange}
      />

      <input
        name="email"
        type="email"
        placeholder="Email"
        required
        onChange={handleChange}
      />

      <input
        name="phone"
        placeholder="Phone (11 digits)"
        required
        onChange={handleChange}
      />

      <input
        name="password"
        type="password"
        placeholder="Password"
        required
        onChange={handleChange}
      />

      <input
        name="confirmPassword"
        type="password"
        placeholder="Confirm Password"
        required
        onChange={handleChange}
      />

      <select name="role" onChange={handleChange}>
        <option value="USER">User</option>
        <option value="CREATOR">Creator</option>
      </select>

      <button type="submit">Register</button>
    </form>
  );
};

export default Register;
