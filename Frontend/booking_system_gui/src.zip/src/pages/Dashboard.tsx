import React, { useEffect, useState, useContext } from 'react';
import { getEvents } from '../api/events.api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';

interface Event {
  id: number;
  name: string;
  description: string;
  category: string;
  location: string;
  date: string;
  time: string;
  ticketPrice: number;
  availableTickets: number;
  imageUrl: string;
  creator: {
    id: string;
  };
}

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const { userRole, userId } = useContext(AuthContext);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const data = await getEvents();
        setEvents(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchEvents();
  }, []);

  const handleBook = async (eventId: number) => {
    const cardNumber = prompt('Enter your card number (16 digits):');
    if (!cardNumber) return;

    try {
      await API.post(`/events/book/${eventId}`, { cardNumber });
      alert('Ticket booked successfully!');

      setEvents((prev) =>
        prev.map((e) =>
          e.id === eventId
            ? { ...e, availableTickets: e.availableTickets - 1 }
            : e
        )
      );
    } catch (err: any) {
      alert(err.response?.data?.message || 'Booking failed');
    }
  };

  const handleDelete = async (eventId: number) => {
    try {
      await API.post(`/events/cancel/${eventId}`);
      alert('Event deleted successfully!');
      setEvents((prev) => prev.filter((e) => e.id !== eventId));
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to delete event');
    }
  };

  if (loading) return <p>Loading events...</p>;
  if (events.length === 0) return <p>No upcoming events</p>;

  return (
    <div>
      <h2>Upcoming Events</h2>
      {events.map((event) => (
        <div
          key={event.id}
          style={{
            border: '1px solid #ccc',
            marginBottom: 15,
            padding: 10,
            display: 'flex',
            gap: 15,
          }}
        >
          <img
            src={`http://localhost:3001/uploads/${event.imageUrl}`}
            alt={event.name}
            style={{ width: 150, height: 100, objectFit: 'cover' }}
          />
          <div>
            <h3>{event.name}</h3>
            <p>{event.description}</p>
            <p>
              {event.category} | {event.location}
            </p>
            <p>
              {event.date} {event.time}
            </p>
            <p>Price: ${event.ticketPrice}</p>
            <p>Available Tickets: {event.availableTickets}</p>

            {/* USER BOOKING */}
            {userRole === 'USER' && event.availableTickets > 0 && (
              <button onClick={() => handleBook(event.id)}>Book Ticket</button>
            )}

            {userRole === 'USER' && event.availableTickets === 0 && (
              <span style={{ color: 'red' }}>Sold Out</span>
            )}

            {/* CREATOR: ONLY OWN EVENTS */}
            {userRole === 'CREATOR' && event.creator.id === userId && (
              <>
                <button onClick={() => handleDelete(event.id)}>Delete Event</button>
                <button onClick={() => navigate(`/update-event/${event.id}`)} style={{ marginLeft: 10 }}>Update</button>
              </>
            )}

            {userRole === 'CREATOR' && event.creator.id !== userId && (
              <span style={{ color: 'gray' }}>You cannot modify this event</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default Dashboard;
