import React, { useEffect, useState } from 'react';
import { getMyBookings } from '../../api/bookings.api';
import axios from '../../api/axios';

interface Booking {
  id: number;
  cancelled: boolean;
  event: {
    name: string;
    date: string;
    time: string;
    ticketPrice: number;
  };
}

const MyBookings: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const data = await getMyBookings();
        setBookings(data);
      } catch (err) {
        console.error('Failed to load bookings', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBookings();
  }, []);

  const handleCancel = async (id: number) => {
    try {
      await axios.post(`/events/cancel-booking/${id}`);
      alert('Booking cancelled and refund processed');

      // mark as cancelled instead of removing
      setBookings((prev) =>
        prev.map((b) =>
          b.id === id ? { ...b, cancelled: true } : b
        )
      );
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to cancel booking');
    }
  };

  if (loading) return <p>Loading bookings...</p>;
  if (bookings.length === 0) return <p>No bookings found</p>;

  return (
    <div>
      <h2>My Bookings</h2>
      <ul>
        {bookings.map((b) => (
          <li key={b.id}>
            <strong>{b.event.name}</strong> — {b.event.date} {b.event.time} — $
            {b.event.ticketPrice}

            {!b.cancelled && (
              <button onClick={() => handleCancel(b.id)}>
                Cancel
              </button>
            )}

            {b.cancelled && (
              <span style={{ color: 'red', marginLeft: 8 }}>
                Cancelled
              </span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MyBookings;
