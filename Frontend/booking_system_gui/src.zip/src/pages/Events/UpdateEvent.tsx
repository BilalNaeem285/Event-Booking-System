import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import API from '../../api/axios';

interface Event {
  id: number;
  name: string;
  description: string;
  category: string;
  location: string;
  date: string;
  time: string;
  ticketPrice: number;
  totalTickets: number;
  availableTickets: number;
  imageUrl: string;
}

const UpdateEvent: React.FC = () => {
  const { eventId } = useParams<{ eventId: string }>();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    description: '',
    category: '',
    location: '',
    date: '',
    time: '',
    ticketPrice: 0,
    totalTickets: 0,
  });

  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // ============================
  // FETCH EVENT (CREATOR ONLY)
  // ============================
  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await API.get('/events/my-events');
        const event = res.data.find((e: Event) => e.id === Number(eventId));

        if (!event) {
          alert('Event not found or not yours');
          navigate('/dashboard');
          return;
        }

        setForm({
          name: event.name,
          description: event.description,
          category: event.category,
          location: event.location,
          date: event.date,
          time: event.time,
          ticketPrice: event.ticketPrice,
          totalTickets: event.totalTickets,
        });

        setCurrentImage(event.imageUrl);
      } catch (err) {
        console.error(err);
        navigate('/dashboard');
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [eventId, navigate]);

  // ============================
  // INPUT HANDLERS
  // ============================
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;

    setForm(prev => ({
      ...prev,
      [name]:
        name === 'ticketPrice' || name === 'totalTickets'
          ? Number(value)
          : value,
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNewImage(e.target.files[0]);
    }
  };

  // ============================
  // SUBMIT UPDATE
  // ============================
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const formData = new FormData();

      // append ALL fields explicitly
      formData.append('name', form.name);
      formData.append('description', form.description);
      formData.append('category', form.category);
      formData.append('location', form.location);
      formData.append('date', form.date);
      formData.append('time', form.time);
      formData.append('ticketPrice', String(form.ticketPrice));
      formData.append('totalTickets', String(form.totalTickets));

      if (newImage) {
        formData.append('image', newImage);
      }

      // 🚫 DO NOT set Content-Type manually
      await API.patch(`/events/update/${eventId}`, formData);

      alert('Event updated successfully!');
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to update event');
    }
  };

  if (loading) return <p>Loading event data...</p>;

  // ============================
  // UI
  // ============================
  return (
    <form
      onSubmit={handleSubmit}
      style={{ maxWidth: 500, margin: '0 auto' }}
    >
      <h2>Update Event</h2>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {currentImage && (
        <img
          src={`http://localhost:3001${currentImage}`}
          alt="Current event"
          style={{ width: '100%', marginBottom: 10 }}
        />
      )}

      <input
        name="name"
        placeholder="Event Name"
        value={form.name}
        onChange={handleChange}
        required
      />

      <textarea
        name="description"
        placeholder="Description"
        value={form.description}
        onChange={handleChange}
        required
      />

      <input
        name="category"
        placeholder="Category"
        value={form.category}
        onChange={handleChange}
        required
      />

      <input
        name="location"
        placeholder="Location"
        value={form.location}
        onChange={handleChange}
        required
      />

      <input
        name="date"
        type="date"
        value={form.date}
        onChange={handleChange}
        required
      />

      <input
        name="time"
        type="time"
        value={form.time}
        onChange={handleChange}
        required
      />

      <input
        name="totalTickets"
        type="number"
        placeholder="Total Tickets"
        value={form.totalTickets}
        onChange={handleChange}
        required
      />

      <input
        name="ticketPrice"
        type="number"
        placeholder="Ticket Price"
        value={form.ticketPrice}
        onChange={handleChange}
        required
      />

      <input type="file" accept="image/*" onChange={handleFileChange} />

      <button type="submit" style={{ marginTop: 10 }}>
        Update Event
      </button>
    </form>
  );
};

export default UpdateEvent;
