import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../../api/axios';

const CreateEvent: React.FC = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    description: '',
    category: '',
    location: '',
    date: '',
    time: '',
    totalTickets: 0,
    ticketPrice: 0,
  });
  const [image, setImage] = useState<File | null>(null);
  const [error, setError] = useState('');

  // --- HELPER LOGIC: 24-HOUR VALIDATION ---
  
  // Gets the date string for "Tomorrow" (YYYY-MM-DD) for the date picker 'min' attribute
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1); 
    return tomorrow.toISOString().split('T')[0];
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: name === 'totalTickets' || name === 'ticketPrice' ? Number(value) : value,
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (!selectedFile.type.startsWith('image/')) {
        setError('Only image files are allowed.');
        return;
      }
      setImage(selectedFile);
      setError('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // 1. Image Check
    if (!image) {
      setError('Event image is required');
      return;
    }

    // 2. Strict 24-Hour Check (Frontend Safety)
    const selectedDateTime = new Date(`${form.date}T${form.time}`);
    const minAllowedTime = new Date();
    minAllowedTime.setHours(minAllowedTime.getHours() + 24);

    if (selectedDateTime < minAllowedTime) {
      setError('Events must be scheduled at least 24 hours from current time.');
      return;
    }

    try {
      const formData = new FormData();
      Object.entries(form).forEach(([key, value]) => formData.append(key, value as any));
      formData.append('image', image);

      await API.post('/events/create', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      alert('Event created successfully!');
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to create event');
    }
  };

  return (
    <div style={{ maxWidth: 500, margin: '20px auto', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h2>Create Event</h2>
        {error && <p style={{ color: 'white', background: 'red', padding: '10px', borderRadius: '4px' }}>{error}</p>}

        <input name="name" placeholder="Event Name" onChange={handleChange} required />
        <textarea name="description" placeholder="Description" onChange={handleChange} required style={{ height: '80px' }} />
        <input name="category" placeholder="Category" onChange={handleChange} required />
        <input name="location" placeholder="Location" onChange={handleChange} required />
        
        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: '12px', display: 'block' }}>Event Date (Min: Tomorrow)</label>
            <input 
              name="date" 
              type="date" 
              min={getMinDate()} // Prevents selection of today or past
              onChange={handleChange} 
              required 
              style={{ width: '100%' }}
            />
          </div>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: '12px', display: 'block' }}>Event Time</label>
            <input 
              name="time" 
              type="time" 
              onChange={handleChange} 
              required 
              style={{ width: '100%' }}
            />
          </div>
        </div>

        <input
          name="totalTickets"
          type="number"
          placeholder="Total Tickets"
          min={1}
          onChange={handleChange}
          required
        />
        <input
          name="ticketPrice"
          type="number"
          placeholder="Ticket Price"
          min={0}
          step={0.01}
          onChange={handleChange}
          required
        />

        <label style={{ fontSize: '12px' }}>Event Banner Image</label>
        <input type="file" accept="image/*" onChange={handleFileChange} required />

        <button type="submit" style={{ marginTop: 10, padding: '10px', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
          Create Event
        </button>
      </form>
    </div>
  );
};

export default CreateEvent;