import React, { useEffect, useState } from 'react';
import API from '../../api/axios';

interface EventType {
  id: number;
  name: string;
  date: string;
  availableTickets: number;
}

const DeleteEvent: React.FC = () => {
  const [events, setEvents] = useState<EventType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await API.get('/events');
        setEvents(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchEvents();
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await API.post(`/events/cancel/${id}`); // Cancel event API
      alert('Event deleted/cancelled successfully!');
      setEvents((prev) => prev.filter((ev) => ev.id !== id));
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to delete event');
    }
  };

  if (loading) return <p>Loading events...</p>;

  return (
    <div>
      <h2>Delete Event</h2>
      <ul>
        {events.map((ev) => (
          <li key={ev.id}>
            {ev.name} - {ev.date} - {ev.availableTickets} tickets
            <button onClick={() => handleDelete(ev.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DeleteEvent;
