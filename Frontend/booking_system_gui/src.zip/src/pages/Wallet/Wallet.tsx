import React, { useEffect, useState } from 'react';
import { getCreatorWallet } from '../../api/users.api';

interface Wallet {
  balance: number | string;
  updatedAt: string;
}

const Wallet: React.FC = () => {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchWallet = async () => {
      try {
        const data = await getCreatorWallet();
        setWallet(data);
      } catch (err) {
        setError('Failed to load wallet');
      } finally {
        setLoading(false);
      }
    };

    fetchWallet();
  }, []);

  if (loading) return <p>Loading wallet...</p>;
  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!wallet) return <p>No wallet found</p>;

  // ✅ SAFE conversion
  const balanceNumber = Number(wallet.balance);

  return (
    <div style={{ maxWidth: 400, margin: '0 auto' }}>
      <h2>Creator Wallet</h2>

      <p>
        <strong>Balance:</strong>{' '}
        ${isNaN(balanceNumber) ? '0.00' : balanceNumber.toFixed(2)}
      </p>

      <p>
        <strong>Last Updated:</strong>{' '}
        {new Date(wallet.updatedAt).toLocaleString()}
      </p>
    </div>
  );
};

export default Wallet;
