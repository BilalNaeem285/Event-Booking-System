import React, { useEffect, useState } from 'react';
import { getNotifications, type Notification } from '../../api/notifications.api';

const Notifications: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const data = await getNotifications();
        setNotifications(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  if (loading) return <p>Loading notifications...</p>;
  if (notifications.length === 0) return <p>No notifications</p>;

  return (
    <div>
      <h2>Notifications</h2>
      <ul>
        {notifications.map((n) => (
          <li key={n.id}>
            {n.message} - {new Date(n.createdAt).toLocaleString()}
            {n.read ? ' ✅' : ' ❌'}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Notifications;
