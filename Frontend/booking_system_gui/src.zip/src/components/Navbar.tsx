import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const { token, userRole, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav style={{ padding: '10px', borderBottom: '1px solid #ccc' }}>
      <Link to="/dashboard" style={{ marginRight: '15px' }}>Dashboard</Link>

      {!token && (
        <>
          <Link to="/login" style={{ marginRight: '15px' }}>Login</Link>
          <Link to="/register" style={{ marginRight: '15px' }}>Sign Up</Link>
        </>
      )}

      {token && userRole === 'USER' && (
        <>
          <Link to="/mybookings" style={{ marginRight: '15px' }}>My Bookings</Link>
          <Link to="/notifications" style={{ marginRight: '15px' }}>Notifications</Link>
        </>
      )}

      {token && userRole === 'CREATOR' && (
        <>
          <Link to="/create-event" style={{ marginRight: '15px' }}>Create Event</Link>
          <Link to="/wallet" style={{ marginRight: '15px' }}>Wallet</Link>
          <Link to="/notifications" style={{ marginRight: '15px' }}>Notifications</Link>
        </>
      )}

      {token && <button onClick={handleLogout}>Logout</button>}
    </nav>
  );
};

export default Navbar;
